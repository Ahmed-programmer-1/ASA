import sys
from fastget.cli import main
sys.exit(main())
