# fastget

Fast multi-connection downloader with live extraction. Pure Python 3.8+, no pip packages.

    python fastget.py                 # asks for the URL
    python fastget.py URL -c 32       # 32 connections
    python fastget.py URL --no-stream # extract after download instead of during it
    python fastget.py URL --no-extract --delete -o D:\Downloads

Re-run the same URL after Ctrl+C / network loss to resume.

Extractors (any one is enough; RAR cannot be decoded in pure Python):
- Live extraction while downloading: bsdtar / Windows 10+ built-in `tar.exe`
- Fallback after download: UnRAR/WinRAR, 7-Zip, unar
