"""fastget - multi-connection downloader with concurrent (streaming) extraction."""
__version__ = "1.0.0"
