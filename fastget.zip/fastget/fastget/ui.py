"""Terminal helpers: human sizes + live progress line."""
from __future__ import annotations

import os
import shutil
import sys
import time
from collections import deque

if os.name == "nt":
    os.system("")  # enable ANSI / VT processing on Windows 10+


def hsize(n: float) -> str:
    for u in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.2f} {u}"
        n /= 1024
    return f"{n:.2f} TB"


def htime(s: float) -> str:
    if s != s or s == float("inf") or s > 359999:
        return "--:--"
    s = int(s)
    h, r = divmod(s, 3600)
    m, s = divmod(r, 60)
    return f"{h:d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


class Progress:
    def __init__(self, total, plain=False):
        self.total = total
        self.plain = plain or not sys.stdout.isatty()
        self._last_plain = 0.0
        self.win = deque(maxlen=12)       # (time, bytes) samples ~ 6 seconds
        self.t0 = time.time()
        self.peak = 0.0

    def speed(self, done: int) -> float:
        now = time.time()
        self.win.append((now, done))
        if len(self.win) < 2:
            return 0.0
        (t1, b1), (t2, b2) = self.win[0], self.win[-1]
        sp = (b2 - b1) / max(t2 - t1, 1e-6)
        self.peak = max(self.peak, sp)
        return sp

    def render(self, done: int, extract_text: str = "") -> None:
        sp = self.speed(done)
        width = max(shutil.get_terminal_size((100, 20)).columns - 1, 60)
        if self.total:
            frac = min(done / self.total, 1.0)
            eta = (self.total - done) / sp if sp > 0 else float("inf")
            bar_w = 22
            fill = int(bar_w * frac)
            bar = "#" * fill + "-" * (bar_w - fill)
            line = (f"[{bar}] {frac*100:5.1f}%  {hsize(done)}/{hsize(self.total)}  "
                    f"{hsize(sp)}/s ({sp*8/1e6:.0f} Mbps)  ETA {htime(eta)}")
        else:
            line = f"{hsize(done)}  {hsize(sp)}/s ({sp*8/1e6:.0f} Mbps)"
        if extract_text:
            line += f"  | {extract_text}"
        if self.plain:                      # IDE / redirected output: one line per 2s
            now = time.time()
            if now - self._last_plain >= 2.0:
                self._last_plain = now
                print(line, flush=True)
            return
        sys.stdout.write("\x1b[2K\r" + line[:width])
        sys.stdout.flush()

    def end(self) -> None:
        if not self.plain:
            sys.stdout.write("\n")
            sys.stdout.flush()
