"""Step 2: segmented multi-connection downloader.

Design for maximum throughput:
  * file is cut into many chunks; N worker threads pull chunks from a shared queue
    (so fast connections automatically take more work - no idle tail);
  * chunks are handed out in ascending order, so the contiguous "watermark" from
    byte 0 advances steadily - this is what lets the extractor start immediately;
  * each worker keeps one persistent keep-alive connection and a big socket buffer,
    and reads straight into a reusable buffer (no per-block allocation);
  * every worker writes through its own file handle into a pre-allocated file;
  * per-chunk retries with reconnect + backoff; resume state saved to disk.
"""
from __future__ import annotations

import collections
import http.client
import json
import os
import socket
import ssl
import threading
import time
import urllib.parse
import urllib.request
from typing import Dict, Optional

from .probe import Info, default_headers

BLOCK = 1 << 20            # 1 MiB read block
MAX_RETRY = 8
REDIRECTS = (301, 302, 303, 307, 308)


class DownloadError(Exception):
    pass


class Downloader:
    def __init__(self, info: Info, dest: str, connections: int = 16,
                 chunk_size: Optional[int] = None,
                 headers: Optional[Dict[str, str]] = None):
        self.info = info
        self.dest = dest
        self.size = info.size
        self.headers = default_headers(headers, info.url)
        self.ranged = info.ranges and bool(info.size)
        self.connections = max(1, connections)
        self.state_path = dest + ".fgstate"

        if self.ranged:
            if chunk_size is None:
                # ~4 chunks per connection, clamped to 2..16 MiB
                chunk_size = min(max(self.size // (self.connections * 4), 2 << 20), 16 << 20)
            self.chunk = chunk_size
            self.n = (self.size + self.chunk - 1) // self.chunk
            self.done = bytearray(self.n)
            self.workers = min(self.connections, self.n)
        else:
            self.chunk, self.n, self.done, self.workers = 0, 0, bytearray(), 1

        self.cv = threading.Condition()
        self._wm = 0                       # first chunk index not yet complete (contiguous)
        self._avail = 0                    # used in single-stream mode
        self.counters = [0] * self.workers  # bytes received per worker
        self.base = 0                      # bytes already present from a previous run
        self.queue = collections.deque()
        self.qlock = threading.Lock()
        self.stop = threading.Event()
        self.finished = threading.Event()
        self.error: Optional[BaseException] = None
        self.last_error = (0.0, "")
        self.retries = 0
        self.threads = []

        self._target_lock = threading.Lock()
        self._set_target(info.url)
        self._ctx = ssl.create_default_context()

    # ------------------------------------------------------------------ target
    def _set_target(self, url: str) -> None:
        u = urllib.parse.urlsplit(url)
        path = (u.path or "/") + (("?" + u.query) if u.query else "")
        self._target = (u.scheme, u.hostname, u.port, path)
        self._gen = getattr(self, "_gen", 0) + 1

    def _connect(self):
        scheme, host, port, _ = self._target
        if scheme == "https":
            c = http.client.HTTPSConnection(host, port, timeout=30, context=self._ctx)
        else:
            c = http.client.HTTPConnection(host, port, timeout=30)
        c.connect()
        try:
            c.sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 4 << 20)
            c.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        return c

    # ------------------------------------------------------------------ state
    def _load_state(self) -> None:
        if not (os.path.exists(self.state_path) and os.path.exists(self.dest)):
            return
        try:
            st = json.load(open(self.state_path))
            if st["size"] != self.size or st["chunk"] != self.chunk:
                return
            if os.path.getsize(self.dest) != self.size:
                return
            for i in st["done"]:
                self.done[i] = 1
            self.base = sum(self._len(i) for i in st["done"])
        except Exception:
            self.done = bytearray(self.n)
            self.base = 0

    def _save_state(self) -> None:
        with self.cv:
            done = [i for i, v in enumerate(self.done) if v]
        tmp = self.state_path + ".tmp"
        with open(tmp, "w") as f:
            json.dump({"size": self.size, "chunk": self.chunk, "done": done}, f)
        os.replace(tmp, self.state_path)

    def _saver(self) -> None:
        while not self.finished.wait(3.0):
            try:
                self._save_state()
            except OSError:
                pass

    def _len(self, i: int) -> int:
        return min(self.chunk, self.size - i * self.chunk)

    # ------------------------------------------------------------------ public
    def start(self) -> None:
        d = os.path.dirname(os.path.abspath(self.dest))
        os.makedirs(d, exist_ok=True)

        if self.ranged:
            self._load_state()
            if self.base == 0 or not os.path.exists(self.dest):
                with open(self.dest, "wb") as f:       # pre-allocate (sparse)
                    f.truncate(self.size)
            while self._wm < self.n and self.done[self._wm]:
                self._wm += 1
            self.queue.extend(i for i in range(self.n) if not self.done[i])
            if not self.queue:
                self.finished.set()
                return
            for w in range(self.workers):
                t = threading.Thread(target=self._worker, args=(w,), daemon=True)
                t.start()
                self.threads.append(t)
            threading.Thread(target=self._saver, daemon=True).start()
        else:
            t = threading.Thread(target=self._single, daemon=True)
            t.start()
            self.threads.append(t)

        threading.Thread(target=self._watch, daemon=True).start()

    def _watch(self) -> None:
        for t in self.threads:
            t.join()
        if not self.stop.is_set() and self.error is None:
            if self.ranged:
                with self.cv:
                    ok = all(self.done)
                if not ok:
                    self.error = DownloadError("download ended with missing chunks")
        with self.cv:
            self.finished.set()
            self.cv.notify_all()
        if self.error is None and self.ranged:
            try:
                os.remove(self.state_path)
            except OSError:
                pass
        elif self.ranged:
            try:
                self._save_state()
            except OSError:
                pass

    def abort(self) -> None:
        self.stop.set()
        with self.cv:
            self.cv.notify_all()

    def received(self) -> int:
        return self.base + sum(self.counters)

    def available(self) -> int:
        """Bytes from offset 0 that are fully written and contiguous."""
        with self.cv:
            return self._available_locked()

    def _available_locked(self) -> int:
        if self.ranged:
            return self.size if self._wm >= self.n else self._wm * self.chunk
        return self._avail

    def wait_available(self, beyond: int, timeout: float = 1.0) -> int:
        with self.cv:
            if self._available_locked() <= beyond and not self.finished.is_set():
                self.cv.wait(timeout)
            return self._available_locked()

    def wait(self) -> None:
        self.finished.wait()
        if self.error:
            raise DownloadError(str(self.error))

    # ------------------------------------------------------------------ workers
    def _next(self) -> Optional[int]:
        with self.qlock:
            return self.queue.popleft() if self.queue else None

    def _worker(self, wid: int) -> None:
        f = open(self.dest, "r+b", buffering=0)
        buf = bytearray(BLOCK)
        mv = memoryview(buf)
        conn, gen = None, -1
        try:
            while not self.stop.is_set():
                idx = self._next()
                if idx is None:
                    break
                start = idx * self.chunk
                end = start + self._len(idx) - 1
                before = self.counters[wid]
                last_err: Optional[BaseException] = None
                for attempt in range(MAX_RETRY):
                    if self.stop.is_set():
                        return
                    try:
                        if conn is None or gen != self._gen:
                            if conn:
                                conn.close()
                            conn, gen = self._connect(), self._gen
                        conn = self._fetch(conn, f, mv, wid, start, end)
                        last_err = None
                        break
                    except Exception as e:           # network hiccup -> reconnect + retry
                        last_err = e
                        self.last_error = (time.time(), str(e) or repr(e))
                        self.retries += 1
                        self.counters[wid] = before
                        try:
                            conn and conn.close()
                        except Exception:
                            pass
                        conn = None
                        time.sleep(min(0.3 * (2 ** attempt), 5.0))
                if last_err is not None:
                    self.error = DownloadError(f"chunk {idx} failed: {last_err!r}")
                    self.stop.set()
                    with self.cv:
                        self.cv.notify_all()
                    return
                with self.cv:
                    self.done[idx] = 1
                    while self._wm < self.n and self.done[self._wm]:
                        self._wm += 1
                    self.cv.notify_all()
        finally:
            f.close()
            if conn:
                try:
                    conn.close()
                except Exception:
                    pass

    def _fetch(self, conn, f, mv, wid, start, end):
        hdr = dict(self.headers)
        hdr["Range"] = f"bytes={start}-{end}"
        hdr["Connection"] = "keep-alive"
        conn.request("GET", self._target[3], headers=hdr)
        r = conn.getresponse()
        if r.status in REDIRECTS:
            loc = r.getheader("Location")
            r.read()
            if not loc:
                raise DownloadError("redirect without Location")
            with self._target_lock:
                self._set_target(urllib.parse.urljoin(self.info.url, loc))
            raise DownloadError("redirected")       # retry on the new target
        if r.status != 206:
            r.read()
            raise DownloadError(f"HTTP {r.status}")
        f.seek(start)
        remaining = end - start + 1
        while remaining:
            n = r.readinto(mv[:min(BLOCK, remaining)])
            if not n:
                raise DownloadError("connection closed early")
            f.write(mv[:n])
            remaining -= n
            self.counters[wid] += n
        r.read()                                    # drain -> keep-alive stays usable
        if r.will_close:
            conn.close()
            return self._connect()
        return conn

    def _single(self) -> None:
        """Fallback when the server has no Range support: one sequential stream."""
        try:
            req = urllib.request.Request(self.info.url, headers=self.headers)
            buf = bytearray(BLOCK)
            mv = memoryview(buf)
            with urllib.request.urlopen(req, timeout=30) as r, \
                    open(self.dest, "wb", buffering=0) as f:
                while not self.stop.is_set():
                    n = r.readinto(buf)
                    if not n:
                        break
                    f.write(mv[:n])
                    self.counters[0] += n
                    with self.cv:
                        self._avail = self.counters[0]
                        self.cv.notify_all()
            if self.size and self.counters[0] != self.size and not self.stop.is_set():
                raise DownloadError("size mismatch")
        except Exception as e:
            self.error = e
            self.stop.set()
