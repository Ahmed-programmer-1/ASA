"""Step 1: inspect the remote file (size, range support, real filename)."""
from __future__ import annotations

import os
import re
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Dict, Optional

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")


@dataclass
class Info:
    url: str                 # final URL (after redirects)
    size: Optional[int]      # bytes, None if unknown
    ranges: bool             # server supports Range requests
    filename: str


def normalize_url(url: str) -> str:
    url = url.strip().strip('"').strip("'")
    return urllib.parse.quote(url, safe=":/?&=%#+@,;~!$'()*[]")


def _filename(headers, url: str) -> str:
    cd = headers.get("Content-Disposition", "") or ""
    name = ""
    m = re.search(r"filename\*\s*=\s*(?:UTF-8'')?([^;]+)", cd, re.I)
    if m:
        name = urllib.parse.unquote(m.group(1).strip().strip('"'))
    else:
        m = re.search(r'filename\s*=\s*"?([^";]+)"?', cd, re.I)
        if m:
            name = m.group(1).strip()
    if not name:
        name = urllib.parse.unquote(os.path.basename(urllib.parse.urlparse(url).path))
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip(" .")
    return name or "download.bin"


def default_headers(extra: Optional[Dict[str, str]] = None, url: str = "") -> Dict[str, str]:
    h = {"User-Agent": UA, "Accept": "*/*", "Accept-Encoding": "identity"}
    if url:
        p = urllib.parse.urlparse(url)
        h["Referer"] = f"{p.scheme}://{p.netloc}/"
    h.update(extra or {})
    return h


def probe(url: str, extra_headers: Optional[Dict[str, str]] = None) -> Info:
    headers = default_headers(extra_headers, url)
    headers["Range"] = "bytes=0-0"
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as r:
        final = r.geturl()
        size: Optional[int] = None
        ranges = False
        cr = r.headers.get("Content-Range")
        if r.status == 206 and cr:
            ranges = True
            tail = cr.rsplit("/", 1)[-1]
            size = int(tail) if tail.isdigit() else None
        else:
            cl = r.headers.get("Content-Length")
            size = int(cl) if cl and cl.isdigit() else None
        name = _filename(r.headers, url)
    return Info(final, size, ranges and size is not None, name)
