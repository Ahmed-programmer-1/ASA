"""Step 3: extraction.

Two modes:
  * STREAM  - while the download is still running, the contiguous bytes that are
              already on disk are piped into bsdtar/libarchive (RAR/ZIP/TAR are
              readable as streams), so extraction finishes right after the download.
  * POST    - after download, run the best native extractor (unrar / 7z / unar /
              bsdtar / python). Used as a fallback if streaming fails.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tarfile
import tempfile
import threading
import zipfile
from typing import List, Optional

STREAM_EXT = (".rar", ".zip", ".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz",
              ".tar.bz2", ".tbz2", ".tar.zst")
ARCHIVE_EXT = STREAM_EXT + (".7z", ".gz", ".xz", ".bz2", ".cab", ".iso")

_WIN_DIRS = [r"C:\Program Files\7-Zip", r"C:\Program Files (x86)\7-Zip",
             r"C:\Program Files\WinRAR", r"C:\Program Files (x86)\WinRAR"]


def is_archive(name: str) -> bool:
    return name.lower().endswith(ARCHIVE_EXT)


def _which(*names: str) -> Optional[str]:
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    if os.name == "nt":
        for d in _WIN_DIRS:
            for n in names:
                p = os.path.join(d, n if n.lower().endswith(".exe") else n + ".exe")
                if os.path.exists(p):
                    return p
    return None


def find_bsdtar() -> Optional[str]:
    """Return a libarchive-based tar (bsdtar, or tar.exe on Windows 10+)."""
    for c in ("bsdtar", "tar"):
        p = shutil.which(c)
        if not p:
            continue
        try:
            out = subprocess.run([p, "--version"], capture_output=True, text=True,
                                 timeout=10).stdout.lower()
        except Exception:
            continue
        if "bsdtar" in out or "libarchive" in out:
            return p
    return None


def find_gnutar() -> Optional[str]:
    p = shutil.which("tar")
    if not p:
        return None
    try:
        out = subprocess.run([p, "--version"], capture_output=True, text=True,
                             timeout=10).stdout.lower()
        return p if "gnu tar" in out else None
    except Exception:
        return None


# ---------------------------------------------------------------------- stream
class StreamExtractor(threading.Thread):
    """Pipes the growing, contiguous prefix of the archive into an extractor."""

    def __init__(self, cmd: List[str], dl, archive: str):
        super().__init__(daemon=True)
        self.cmd, self.dl, self.archive = cmd, dl, archive
        self.fed = 0
        self.ok = False
        self.err = ""
        self.stop = threading.Event()

    def run(self) -> None:
        errf = tempfile.TemporaryFile()
        try:
            proc = subprocess.Popen(self.cmd, stdin=subprocess.PIPE,
                                    stdout=subprocess.DEVNULL, stderr=errf)
        except OSError as e:
            self.err = str(e)
            return
        broken = False
        try:
            while not self.stop.is_set():
                # wait until the file is at least created
                if os.path.exists(self.archive):
                    break
                self.dl.wait_available(0, 0.2)
            with open(self.archive, "rb", buffering=0) as f:
                while not self.stop.is_set():
                    avail = self.dl.wait_available(self.fed, 0.5)
                    if avail > self.fed:
                        data = f.read(min(avail - self.fed, 8 << 20))
                        if not data:
                            continue
                        try:
                            proc.stdin.write(data)
                        except (BrokenPipeError, OSError):
                            broken = True      # extractor exited (finished or failed)
                            break
                        self.fed += len(data)
                    elif self.dl.finished.is_set() or self.dl.error:
                        break
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            if self.stop.is_set():
                proc.kill()
            rc = proc.wait()
            errf.seek(0)
            self.err = errf.read().decode("utf-8", "replace").strip()[-600:]
            errf.close()
            complete = self.dl.error is None and self.dl.finished.is_set() \
                and (broken or self.fed >= (self.dl.size or self.fed))
            self.ok = (rc == 0) and complete


def stream_command(archive_name: str, outdir: str) -> Optional[List[str]]:
    """Pick an extractor able to read the archive from stdin, or None."""
    low = archive_name.lower()
    if not low.endswith(STREAM_EXT):
        return None
    os.makedirs(outdir, exist_ok=True)
    bsd = find_bsdtar()
    if bsd:
        return [bsd, "-xf", "-", "-C", outdir]
    if low.endswith((".tar", ".tar.gz", ".tgz", ".tar.xz", ".txz", ".tar.bz2", ".tbz2")):
        gnu = find_gnutar()
        if gnu:
            flag = ("-z" if low.endswith((".gz", ".tgz")) else
                    "-J" if low.endswith((".xz", ".txz")) else
                    "-j" if low.endswith((".bz2", ".tbz2")) else "")
            return [gnu, "-x"] + ([flag] if flag else []) + ["-f", "-", "-C", outdir]
    return None


# ------------------------------------------------------------------------ post
def post_extract(archive: str, outdir: str, log=print) -> bool:
    os.makedirs(outdir, exist_ok=True)
    low = archive.lower()
    tries = []

    if low.endswith(".rar"):
        u = _which("unrar", "UnRAR")
        if u:
            tries.append(("unrar", [u, "x", "-o+", "-y", "-idq", archive, outdir + os.sep]))
    z = _which("7zz", "7z", "7za")
    if z:
        tries.append(("7-zip", [z, "x", "-y", "-mmt=on", f"-o{outdir}", archive]))
    ua = _which("unar")
    if ua:
        tries.append(("unar", [ua, "-f", "-o", outdir, archive]))
    bsd = find_bsdtar()
    if bsd:
        tries.append(("bsdtar", [bsd, "-xf", archive, "-C", outdir]))

    for name, cmd in tries:
        log(f"extracting with {name} ...")
        rc = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        if rc.returncode == 0:
            return True
        log(f"{name} failed: {rc.stderr.decode('utf-8', 'replace').strip()[-300:]}")

    # pure-python fallbacks
    try:
        if low.endswith(".zip"):
            log("extracting with python zipfile ...")
            with zipfile.ZipFile(archive) as zf:
                zf.extractall(outdir)
            return True
        if tarfile.is_tarfile(archive):
            log("extracting with python tarfile ...")
            with tarfile.open(archive) as tf:
                tf.extractall(outdir)
            return True
    except Exception as e:
        log(f"python fallback failed: {e}")

    log("no working extractor found. Install 7-Zip (https://7-zip.org) or WinRAR/unrar.")
    return False
