"""Step 4: command line front-end that glues everything together."""
from __future__ import annotations

import argparse
import os
import sys
import time

from . import __version__
from .downloader import DownloadError, Downloader
from .extractor import (StreamExtractor, is_archive, post_extract,
                        stream_command)
from .probe import normalize_url, probe
from .ui import Progress, hsize, htime


def parse_args(argv=None):
    p = argparse.ArgumentParser(prog="fastget",
                                description="Fast multi-connection downloader + live extractor")
    p.add_argument("url", nargs="?", help="file URL (asked interactively if omitted)")
    p.add_argument("-o", "--out", default="downloads", help="output directory (default: ./downloads)")
    p.add_argument("-c", "--connections", type=int, default=16,
                   help="parallel connections (default 16; try 32 if server allows)")
    p.add_argument("--chunk-mb", type=int, default=None, help="chunk size in MiB (default: auto)")
    p.add_argument("--no-extract", action="store_true", help="download only")
    p.add_argument("--no-stream", action="store_true",
                   help="don't extract during download; extract after it finishes")
    p.add_argument("--plain", action="store_true", help="print a new progress line every 2s (for IDEs / logs)")
    p.add_argument("--delete", action="store_true", help="delete the archive after successful extraction")
    p.add_argument("-H", "--header", action="append", default=[],
                   help='extra header, e.g. -H "Cookie: a=b" (repeatable)')
    p.add_argument("-V", "--version", action="version", version=__version__)
    return p.parse_args(argv)


def main(argv=None) -> int:
    a = parse_args(argv)
    url = a.url or input("Enter file URL: ").strip()
    if not url:
        print("no URL given")
        return 1
    url = normalize_url(url)
    extra = {}
    for h in a.header:
        k, _, v = h.partition(":")
        extra[k.strip()] = v.strip()

    print("[1/4] probing server ...")
    try:
        info = probe(url, extra)
    except Exception as e:
        print(f"cannot reach the URL: {e}")
        return 1
    print(f"      file   : {info.filename}")
    print(f"      size   : {hsize(info.size) if info.size else 'unknown'}")
    print(f"      ranges : {'yes -> multi-connection' if info.ranges else 'NO -> single stream (slower)'}")

    out = os.path.abspath(a.out)
    dest = os.path.join(out, info.filename)
    stem = info.filename
    for ext in (".tar.gz", ".tar.xz", ".tar.bz2", ".tar.zst"):
        if stem.lower().endswith(ext):
            stem = stem[:-len(ext)]
            break
    else:
        stem = os.path.splitext(stem)[0]
    outdir = os.path.join(out, stem)

    chunk = a.chunk_mb << 20 if a.chunk_mb else None
    dl = Downloader(info, dest, a.connections, chunk, extra)

    want_extract = (not a.no_extract) and is_archive(info.filename)
    streamer = None
    if want_extract and not a.no_stream:
        cmd = stream_command(info.filename, outdir)
        if cmd:
            streamer = StreamExtractor(cmd, dl, dest)
            print(f"[2/4] downloading with {dl.workers} connections + LIVE extraction")
        else:
            print(f"[2/4] downloading with {dl.workers} connections "
                  "(no streaming extractor found -> will extract after download)")
    else:
        print(f"[2/4] downloading with {dl.workers} connections")

    if dl.base:
        print(f"      resuming: {hsize(dl.base)} already on disk")
    t0 = time.time()
    dl.start()
    if streamer:
        streamer.start()

    prog = Progress(info.size, a.plain)
    try:
        def status():
            parts = []
            if streamer:
                parts.append(f"unpacking {hsize(streamer.fed)}")
            t, msg = dl.last_error
            if msg and time.time() - t < 10:
                parts.append(f"retrying ({dl.retries}): {msg[:40]}")
            return " | ".join(parts)

        while not dl.finished.is_set():
            prog.render(dl.received(), status())
            time.sleep(0.5)
        prog.render(dl.received(), status())
        prog.end()
    except KeyboardInterrupt:
        prog.end()
        dl.abort()
        if streamer:
            streamer.stop.set()
        print("stopped. Run again with the same URL to resume.")
        return 130

    try:
        dl.wait()
    except DownloadError as e:
        if streamer:
            streamer.stop.set()
        print(f"download failed: {e}\nRun again to resume.")
        return 2

    el = time.time() - t0
    got = dl.received() - dl.base
    print(f"[3/4] download done in {htime(el)}  avg {hsize(got / max(el, 1e-6))}/s  "
          f"peak {hsize(prog.peak)}/s")

    ok = True
    if want_extract:
        if streamer:
            print("[4/4] finishing live extraction ...")
            streamer.join()
            ok = streamer.ok
            if not ok:
                print("      streaming extraction did not complete"
                      + (f" ({streamer.err})" if streamer.err else "") + " -> retrying normally")
        if not streamer or not ok:
            print("[4/4] extracting ...")
            ok = post_extract(dest, outdir)
        if ok:
            print(f"extracted to: {outdir}")
            if a.delete:
                os.remove(dest)
                print("archive deleted")
        else:
            print("extraction failed - archive kept at:", dest)
            return 3
    else:
        print(f"[4/4] saved to: {dest}")
    print(f"total time: {htime(time.time() - t0)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
